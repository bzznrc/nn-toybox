# digits8_mini

Small native 8x8 handwritten digit PNG dataset for `nn-toybox`.

## Contents

- `train/`: 500 images total, 50 per digit class
- `inference/`: 100 images total, 10 per digit class
- images are grayscale PNGs
- images are native 8x8 pixels
- inference images are disjoint from training images

## Layout

```text
digits8_mini/
  train/
    0/
    1/
    ...
    9/
  inference/
    0/
    1/
    ...
    9/
  manifest.json
```

## Suggested use

- Train `trace` and `conv` on `train/`.
- Let the Arcade viewer browse `inference/`.
- Visually scale the 8x8 images up at draw time with nearest-neighbor scaling.

## Source

This is a subset/export of scikit-learn's built-in `load_digits` dataset,
which is based on the UCI Optical Recognition of Handwritten Digits dataset.
Original pixel values are 0-16; PNG values are scaled to 0-255.
